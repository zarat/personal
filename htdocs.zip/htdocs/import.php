<?php

include "db.php";

$handle = fopen("kuli2.txt", "r");

$db = new db();

$query = null;

if ($handle) {

    while (($line = fgets($handle)) !== false) {
    
        $fields = explode(";", $line);

        $loopcounter = 0;
        
        $query = "insert into `kunden` ";
        
        $query .= "values (";
        
        foreach( $fields as $field ) {
        
            if($loopcounter == 0) {
                $query .= trim($field);
            } else {
                $query .= "'" . trim($field) . "'";
            }
            if( $loopcounter < count($fields)-1 ) { $query .= ","; }
            $loopcounter++;
            
        }
        
        $query .= ")";
        
        echo $query . "<hr>";   
        
    }

    fclose($handle);
    
} 

if(1==2) {
$con = $db->getconn();
$con->query($query) or die( $con->error );
}

?>