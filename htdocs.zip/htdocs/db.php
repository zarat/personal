<?php

class db {

private $host = "localhost";
private $user = "root";
private $pass = "gewista";
private $database = "vk2000";
private $conn = null;

    function __construct() {
        $this->conn = new mysqli($this->host,$this->user,$this->pass,$this->database);    
    }
    
    public function getconn() {
        return $this->conn;
    }

}

?>